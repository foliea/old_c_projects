/*
** ret_team.h for zappy in /u/epitech_2013/bienve_e/cu/public/zappy/1_adrien
** 
** Made by edern bienvenu
** Login   <bienve_e@epitech.net>
** 
** Started on  Sun Jun 20 17:28:55 2010 edern bienvenu
** Last update Sun Jun 20 17:31:22 2010 edern bienvenu
*/

#ifndef RET_CBUFF_H
#define RET_CBUFF_H

void	cremove_mid_end(t_circular *save);
void	cremove_mid_mid(t_circular *save);
void	cremove_mid_beg(void);

#endif
