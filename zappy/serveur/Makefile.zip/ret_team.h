/*
** ret_team.h for zappy in /u/epitech_2013/bienve_e/cu/public/zappy/1_adrien
** 
** Made by edern bienvenu
** Login   <bienve_e@epitech.net>
** 
** Started on  Sun Jun 20 17:28:55 2010 edern bienvenu
** Last update Sun Jun 20 17:37:18 2010 edern bienvenu
*/

#ifndef RET_TEAM_H
#define RET_TEAM_H

void	remove_mid_end(t_dteam *recup, t_player *save);
void	remove_mid_mid(t_dteam *recup, t_player *save);
void	remove_mid_beg(t_dteam *team);
void	search_in_teams(int fd);

#endif
