/*
** check.h for zappy in /u/epitech_2013/bienve_e/cu/public/zappy/1_adrien
** 
** Made by edern bienvenu
** Login   <bienve_e@epitech.net>
** 
** Started on  Wed Jun 16 00:33:47 2010 edern bienvenu
** Last update Wed Jun 16 02:23:03 2010 edern bienvenu
*/

#ifndef DEATH_H
#define DEATH_H

int	add_death(int t, int fd);

#endif
