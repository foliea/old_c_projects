/*
** check.h for zappy in /u/epitech_2013/bienve_e/cu/public/zappy/1_adrien
** 
** Made by edern bienvenu
** Login   <bienve_e@epitech.net>
** 
** Started on  Wed Jun 16 00:33:47 2010 edern bienvenu
** Last update Sun Jun 20 17:23:25 2010 edern bienvenu
*/

#ifndef VALUE_H
#define VALUE_H

void	new_pos_expulse(t_player *player, int dir);
int	value_k_up(t_player *player);
int	value_k_down(t_player *player);
int	value_k_left(t_player *player);
int	value_k_right(t_player *player);

#endif
