/*
** broad.h for zappy in /u/epitech_2013/bienve_e/cu/public/zappy/1_adrien
** 
** Made by edern bienvenu
** Login   <bienve_e@epitech.net>
** 
** Started on  Sun Jun 20 12:37:49 2010 edern bienvenu
** Last update Sun Jun 20 12:38:48 2010 edern bienvenu
*/

#ifndef BROAD_H
#define BROAD_H

typedef struct	s_broad
{
  char		*msg;
  int		x;
  int		y;
}		t_broad;

#endif
