/*
** parsing.h for zappy in /u/epitech_2013/bienve_e/cu/public/zappy/4_edern
** 
** Made by edern bienvenu
** Login   <bienve_e@epitech.net>
** 
** Started on  Fri May 28 21:29:14 2010 edern bienvenu
** Last update Sat Jun 19 05:05:09 2010 adrien folie
*/

#ifndef PARSING_H
#define PARSING_H

typedef struct	s_parse
{
  int		port;
  int		width;
  int		height;
  int		nb_client;
  int		nb_team;
  int		t;
  int		s;
}		t_parse;

/*---- functions ----*/

#endif
